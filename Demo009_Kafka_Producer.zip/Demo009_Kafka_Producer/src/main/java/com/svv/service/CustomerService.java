package com.svv.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.svv.model.Customer;
import com.svv.utility.KafkaConstants;

@Service
public class CustomerService {
	
	@Autowired
	KafkaTemplate<String,Customer> kafkaTemplate;
	
	public String addCustmer(List<Customer> customers)
	{
		for(Customer customer : customers)
		{
			
			kafkaTemplate.send(KafkaConstants.TOPIC, customer);
			
			System.out.println("Customer info sent to Kafka "+ customer);
		}
		
		return "All Customer info sent to Kafka";
		
	}

}
