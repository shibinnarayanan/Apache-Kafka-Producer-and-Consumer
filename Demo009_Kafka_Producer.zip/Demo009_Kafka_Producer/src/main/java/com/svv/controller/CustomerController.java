package com.svv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.svv.model.Customer;
import com.svv.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerService custService;
	
	@PostMapping(value = "/adduser" , consumes = {"application/json","application/xml"})
	public void addCustomer(@RequestBody List<Customer> customers)
	{
		System.out.println(customers);
		custService.addCustmer(customers);
	}

}
