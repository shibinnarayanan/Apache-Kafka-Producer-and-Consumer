package com.svv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo009KafkaProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo009KafkaProducerApplication.class, args);
	}

}
