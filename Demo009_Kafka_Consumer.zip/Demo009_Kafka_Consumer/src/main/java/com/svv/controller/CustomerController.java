package com.svv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.svv.model.Customer;
import com.svv.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerService custServ;
	
	@GetMapping(value = "/getCustInfo", produces = {"application/json","application/xml"})
	public List<Customer> getAllCustomerInfo()
	{
		return custServ.getCustomerInfo();
	}

}
