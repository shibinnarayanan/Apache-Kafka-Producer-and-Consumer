package com.svv.utility;

import com.svv.model.Customer;

public class KafkaConstants {
	
	public static final String TOPIC = "customerdata";
	public static final String GROUP_ID = "group_customerdata";
	public static final String HOST = "localhost:9092";

}
