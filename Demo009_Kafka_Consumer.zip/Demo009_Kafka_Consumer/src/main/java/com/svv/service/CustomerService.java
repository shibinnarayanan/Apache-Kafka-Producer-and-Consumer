package com.svv.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.retry.backoff.Sleeper;
import org.springframework.stereotype.Service;

import com.svv.model.Customer;
import com.svv.utility.KafkaConstants;

@Service
public class CustomerService {
	
	List<Customer> list = new ArrayList<>();
	
	public List<Customer> getCustomerInfo()
	{
		return list;
	}
	
	@KafkaListener(topics = KafkaConstants.TOPIC ,groupId = KafkaConstants.GROUP_ID)
	public Customer listener(Customer c)
	{
		System.out.println("Kafka listener invoked");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.add(c);
		System.out.println("Message received from kafka topic "+ c);
		
		return c;
	}

}
